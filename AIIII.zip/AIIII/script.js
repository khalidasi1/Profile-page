// Handle image preview when a user selects a profile picture
document.getElementById('profilePicture').addEventListener('change', function(event) {
    const file = event.target.files[0];
    const imagePreview = document.getElementById('imagePreview');
  
    if (file && file.type.startsWith('image/')) {
      const reader = new FileReader();
  
      reader.onload = function(e) {
        imagePreview.src = e.target.result; // Set the image source to the file content
        imagePreview.style.display = 'block'; // Show the image preview
      };
  
      reader.readAsDataURL(file); // Read the file as a Data URL (base64)
    } else {
      imagePreview.src = '';
      imagePreview.style.display = 'none'; // Hide the preview if no valid image is selected
    }
  });
  
  // Handle form submission
  document.getElementById('contactForm').addEventListener('submit', function(event) {
    event.preventDefault(); // Prevent the form from submitting the traditional way
  
    // Get form values
    const name = document.getElementById('name').value.trim();
    const email = document.getElementById('email').value.trim();
    const message = document.getElementById('message').value.trim();
    const fileInput = document.getElementById('profilePicture');
    const file = fileInput.files[0];
  
    const response = document.getElementById('formResponse');
    const emailPattern = /^[a-zA-Z0-9._-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,6}$/; // Email validation pattern
  
    // Basic form validation
    if (name && email && message) {
      if (emailPattern.test(email)) {
        // Display a success message
        response.textContent = `Thanks for reaching out, ${name}! I will respond to your message shortly.`;
        response.style.color = 'green';
  
        // You can handle the file upload and form submission to the server here.
        // For example, using fetch or XMLHttpRequest to send the form data.
  
      } else {
        response.textContent = 'Please enter a valid email address.';
        response.style.color = 'red';
      }
    } else {
      response.textContent = 'Please fill in all fields.';
      response.style.color = 'red';
    }
  
    // Clear the form after submission
    document.getElementById('contactForm').reset();
    document.getElementById('imagePreview').style.display = 'none'; // Hide the preview after submission
  });
  